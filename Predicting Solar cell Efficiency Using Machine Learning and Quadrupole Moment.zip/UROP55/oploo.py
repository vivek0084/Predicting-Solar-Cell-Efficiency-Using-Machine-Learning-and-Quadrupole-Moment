import numpy as np
from sklearn.model_selection import cross_val_predict, LeaveOneOut
from sklearn.metrics import mean_absolute_error, mean_squared_error
from scipy.stats import pearsonr
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import GradientBoostingRegressor

dataset = np.loadtxt('opv_Q20.txt')
features = dataset[:, [0]]
labels = dataset[:, 3]
samples = len(dataset)
cv = LeaveOneOut()

def evaluate(model, name, features, labels, samples):
    print(name + " regression:")
    preds = cross_val_predict(model, features, labels, cv=cv)
    mae = mean_absolute_error(labels, preds)
    rmse = np.sqrt(mean_squared_error(labels, preds))
    correlation = pearsonr(labels, preds)
    print("MAE: {:.2f}".format(mae))
    print("RMSE: {:.2f}".format(rmse))
    print("Pearson's correlation coefficient: ", correlation)
    return preds

regressors = {
    "Linear Regression": LinearRegression(),
    "k-NN Regression": KNeighborsRegressor(n_neighbors=10),
    "Gradient Boosting Regression": GradientBoostingRegressor(random_state=0, max_depth=3, learning_rate=0.04)
}

for name, model in regressors.items():
    preds = evaluate(model, name, features, labels, samples)
    with open(f'Prediction-{name.lower()}.txt', 'wt') as f:
        for i in range(samples):
            print("{:6.2f} {:6.2f}".format(labels[i], preds[i]), file=f)
