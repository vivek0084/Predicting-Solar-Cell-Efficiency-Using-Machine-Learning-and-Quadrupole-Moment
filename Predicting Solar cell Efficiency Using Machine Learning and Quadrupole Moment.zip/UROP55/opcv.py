import numpy as np
from sklearn.model_selection import cross_val_score, KFold, cross_val_predict, GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import GradientBoostingRegressor
from scipy.stats import pearsonr

dataset = np.loadtxt('opv_Q20.txt')
features = dataset[:, [0]]
labels = dataset[:, 2]
samples = len(open('opv_Q20.txt').readlines())
cv = KFold(n_splits=5, shuffle=True, random_state=0)

def regression(model, name, features, labels):
    print(f"{name}:")
    cv_scores = cross_val_score(model, features, labels, cv=cv)
    print("Cross-validation scores:", cv_scores)
    print("Mean accuracy: {:.2f}".format(cv_scores.mean()))
    preds = cross_val_predict(model, features, labels, cv=cv)
    correlation = pearsonr(labels, preds)
    print("Pearson's correlation coefficient:", correlation)
    with open(f'Prediction-{name.lower()}.txt', 'wt') as f:
        for i in range(len(labels)):  # Corrected line
            print("{:6.2f} {:6.2f}".format(labels[i], preds[i]), file=f)

print("Machine Learning starting:")

linear_model = LinearRegression()
regression(linear_model, "Linear Regression", features, labels)

# Define the parameter values that should be searched
k_range = list(range(1, 31))

# Create a parameter grid: map the parameter names to the values that should be searched
param_grid = dict(n_neighbors=k_range)

# Instantiate the grid
grid = GridSearchCV(KNeighborsRegressor(), param_grid, cv=10, scoring='neg_mean_squared_error')

# Fit the grid with data
grid.fit(features, labels)

# View the complete results
print(grid.best_params_)
print(grid.best_score_)

# Update your k-NN model
knn_model = KNeighborsRegressor(n_neighbors=grid.best_params_['n_neighbors'])
regression(knn_model, "k-NN Regression", features, labels)

gbr_model = GradientBoostingRegressor(random_state=0, max_depth=3, learning_rate=0.04)
regression(gbr_model, "Gradient Boosting Regression", features, labels)
